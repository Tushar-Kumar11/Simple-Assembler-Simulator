# Simple-Assembler-Simulator
Designed and Implemented a custom Simple Assembler and Simulator for a given Information Set Architecture.
